import React, { useState } from 'react';
import axios from 'axios';

const ComplaintForm = () => {
    const [formData, setFormData] = useState({
        category: 'Safety',
        description: '',
        address: '',
        contact: '',
        evidence: null // For photo/video proof
    });

    const handleFileChange = (e) => {
        setFormData({...formData, evidence: e.target.files[0]});
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        // Since we are uploading a file, we need to use FormData
        const data = new FormData();
        data.append('category', formData.category);
        data.append('description', formData.description);
        data.append('address', formData.address);
        data.append('contact', formData.contact);
        data.append('evidence', formData.evidence); // Attach the file

        try {
            await axios.post('http://localhost:5000/api/complaints/submit', data);
            alert("Submitted Secretly!");
        } catch (err) {
            alert("Error submitting. Please try again.");
        }
    };

    return (
        <div className="min-h-screen bg-gray-100 flex items-center justify-center p-6">
            <form onSubmit={handleSubmit} className="bg-white p-10 rounded-2xl shadow-xl w-full max-w-lg space-y-6">
                <h1 className="text-3xl font-bold text-gray-900 border-b pb-4">Silent Complaint Portal</h1>
                <p className="text-sm text-gray-600">Your privacy is important to us. Report issues without revealing your identity.</p>

                {/* Better input styling */}
                <div className="space-y-4">
                    <div>
                        <label className="block text-sm font-semibold text-gray-700">Category of Issue</label>
                        <select 
                            className="mt-1 block w-full border-gray-200 rounded-lg shadow-sm focus:ring-red-500 focus:border-red-500 p-3 border"
                            onChange={(e) => setFormData({...formData, category: e.target.value})}
                        >
                            <option value="Safety">Safety</option>
                            <option value="Cleanliness">Cleanliness</option>
                            <option value="Harassment">Harassment</option>
                        </select>
                    </div>

                    <div>
                        <label className="block text-sm font-semibold text-gray-700">Detailed Description</label>
                        <textarea required 
                            className="mt-1 block w-full border-gray-200 rounded-lg shadow-sm focus:ring-red-500 focus:border-red-500 p-3 border h-28"
                            placeholder="Please provide details about what happened?"
                            onChange={(e) => setFormData({...formData, description: e.target.value})}
                        />
                    </div>

                    <div>
                        <label className="block text-sm font-semibold text-gray-700">Specific Location (e.g., Room, Building)</label>
                        <input type="text" required
                            className="mt-1 block w-full border-gray-200 rounded-lg shadow-sm focus:ring-red-500 focus:border-red-500 p-3 border"
                            placeholder="Building A, Room 302"
                            onChange={(e) => setFormData({...formData, address: e.target.value})}
                        />
                    </div>
                    
                    {/* The new evidence upload input */}
                    <div>
                        <label className="block text-sm font-semibold text-gray-700 mb-1">Add Photo Proof (Optional)</label>
                        <div className="flex items-center justify-center w-full">
                            <label className="flex flex-col w-full h-32 border-4 border-dashed border-gray-200 hover:bg-gray-100 hover:border-gray-300 rounded-lg cursor-pointer">
                                <div className="flex flex-col items-center justify-center pt-7">
                                    <svg className="w-10 h-10 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path></svg>
                                    <p className="pt-1 text-sm tracking-wider text-gray-400">Attach file</p>
                                </div>
                                <input type="file" className="opacity-0" accept="image/*" onChange={handleFileChange} />
                            </label>
                        </div>
                    </div>

                    <div>
                        <label className="block text-sm font-semibold text-gray-700">Contact Number (Optional)</label>
                        <input type="text"
                            className="mt-1 block w-full border-gray-200 rounded-lg shadow-sm focus:ring-red-500 focus:border-red-500 p-3 border"
                            placeholder="Only provide if you wish for us to follow up directly."
                            onChange={(e) => setFormData({...formData, contact: e.target.value})}
                        />
                    </div>
                </div>

                <button type="submit"
                    className="w-full bg-red-600 text-white font-semibold py-3 rounded-lg hover:bg-red-700 transition duration-200 shadow-lg hover:shadow-xl"
                >
                    Submit Secretly
                </button>
            </form>
        </div>
    );
};

export default ComplaintForm;