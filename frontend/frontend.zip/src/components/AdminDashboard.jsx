import React, { useEffect, useState } from 'react';
import axios from 'axios';

const AdminDashboard = () => {
    const [complaints, setComplaints] = useState([]);

    useEffect(() => {
        const fetchComplaints = async () => {
            try {
                const res = await axios.get('http://localhost:5000/api/complaints/all');
                setComplaints(res.data);
            } catch (err) {
                console.error("Error fetching data", err);
            }
        };
        fetchComplaints();
    }, []);

    return (
        <div className="min-h-screen bg-gray-50 p-8">
            <h2 className="text-3xl font-bold text-gray-800 mb-6">Admin Complaint Portal</h2>
            <div className="grid gap-4">
                {complaints.length === 0 ? (
                    <p className="text-gray-500">No complaints reported yet.</p>
                ) : (
                    complaints.map((item) => (
                        <div key={item._id} className="bg-white p-6 rounded-lg shadow-sm border-l-4 border-red-500">
                            <div className="flex justify-between items-start">
                                <span className="px-3 py-1 bg-red-100 text-red-700 rounded-full text-sm font-semibold">
                                    {item.category}
                                </span>
                                <span className="text-gray-400 text-sm">
                                    {new Date(item.createdAt).toLocaleDateString()}
                                </span>
                            </div>
                            <p className="mt-3 text-gray-700 font-medium">{item.description}</p>
                            <div className="mt-4 grid grid-cols-2 gap-4 text-sm text-gray-600">
                                <div>
                                    <span className="font-bold">Location:</span> {item.address}
                                </div>
                                <div>
                                    <span className="font-bold">Contact:</span> {item.contact || "Anonymous"}
                                </div>
                            </div>
                            <div className="mt-4 pt-4 border-t flex gap-2">
                                <button className="text-blue-600 hover:underline text-sm font-semibold">Mark Resolved</button>
                                <button className="text-gray-400 hover:text-red-600 text-sm font-semibold ml-auto">Delete</button>
                            </div>
                        </div>
                    ))
                )}
            </div>
        </div>
    );
};

export default AdminDashboard;