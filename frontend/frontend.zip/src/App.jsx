import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import ComplaintForm from './components/ComplaintForm';
import AdminDashboard from './components/AdminDashboard';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-100 font-sans">
        {/* Simple Navigation Bar */}
        <nav className="bg-white shadow-sm p-4 flex justify-center gap-8">
          <Link to="/" className="text-blue-600 font-semibold hover:text-blue-800">Report Issue</Link>
          <Link to="/admin" className="text-gray-600 font-semibold hover:text-blue-800">Admin Login</Link>
        </nav>

        <Routes>
          <Route path="/" element={<ComplaintForm />} />
          <Route path="/admin" element={<AdminDashboard />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;