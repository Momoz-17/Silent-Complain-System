require('dotenv').config(); // Must be at the very top to load .env variables
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const complaintRoutes = require('./routes/complaintRoutes');
const jwt = require('jsonwebtoken');

const app = express();

// Use the PORT from .env or default to 5000 for local development
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json()); 

// MongoDB Connection using the URI from your .env file
const mongoURI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/communityConnect';

mongoose.connect(mongoURI)
    .then(() => console.log("Connected to MongoDB for Silent Complaint System"))
    .catch(err => console.error("Could not connect to MongoDB:", err));

// Routes
app.use('/api/complaints', complaintRoutes);

// Simple Health Check
app.get('/', (req, res) => res.send("Community Connect Server Running"));

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});

// Simple Admin Login Route (Replace with actual DB check for a real system)
app.post('/api/auth/login', async (req, res) => {
    const { email, password } = req.body;
    
    // Check credentials (HARCODED FOR HACKATHON)
    if (email === 'admin@test.com' && password === 'secretadmin123') {
        // Sign a token that expires in 1 hour
        const token = jwt.sign({ id: 'admin1', role: 'admin' }, 'your_secret_key', { expiresIn: '1h' });
        res.json({ success: true, token });
    } else {
        res.status(401).json({ success: false, message: "Invalid credentials" });
    }
});