const express = require('express');
const router = express.Router();
const Complaint = require('../models/Complaint');

// Post a new complaint
router.post('/submit', async (req, res) => {
    try {
        const { category, description, address, contact, evidence } = req.body;
        const newComplaint = new Complaint({ category, description, address, contact, evidence });
        await newComplaint.save();
        res.status(201).json({ message: "Complaint submitted anonymously!", id: newComplaint._id });
    } catch (err) {
        res.status(500).json({ error: "Failed to submit" });
    }
});

// Get all complaints for Admin
router.get('/all', async (req, res) => {
    const complaints = await Complaint.find().sort({ createdAt: -1 });
    res.json(complaints);
});

module.exports = router;